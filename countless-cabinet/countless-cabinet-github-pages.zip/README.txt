COUNTLESS CABINET - STANDALONE GITHUB PAGES SITE

This is the full original HTML copied as index.html.
Upload index.html to a public GitHub repository or folder configured for GitHub Pages.
Visitors do not need a ChatGPT account or GitHub account.
If installing in existing site repository, upload index.html under countless-cabinet/ (it will replace the launcher page).

Note: externally linked resources and third-party services might still require network access or authentication.
